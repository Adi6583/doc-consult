// ==================== Islamic Calendar App - Production Ready ====================

// ==================== Data ====================
const hijriMonths = [
  { name: "Muharram", arabic: "محرم", days: 30 },
  { name: "Safar", arabic: "صفر", days: 29 },
  { name: "Rabi al-Awwal", arabic: "ربيع الأول", days: 30 },
  { name: "Rabi al-Thani", arabic: "ربيع الآخر", days: 29 },
  { name: "Jumada al-Awwal", arabic: "جمادى الأولى", days: 30 },
  { name: "Jumada al-Thani", arabic: "جمادى الآخرة", days: 29 },
  { name: "Rajab", arabic: "رجب", days: 30 },
  { name: "Shaban", arabic: "شعبان", days: 29 },
  { name: "Ramadan", arabic: "رمضان", days: 30 },
  { name: "Shawwal", arabic: "شوال", days: 29 },
  { name: "Dhul Qadah", arabic: "ذو القعدة", days: 30 },
  { name: "Dhul Hijjah", arabic: "ذو الحجة", days: 29 },
]

const gregorianMonths = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December",
]

const weekDays = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]

const islamicEvents = [
  {
    month: 1,
    day: 1,
    name: "Islamic New Year",
    arabic: "رأس السنة الهجرية",
    description: "First day of Muharram marks the beginning of the Islamic calendar year.",
  },
  {
    month: 1,
    day: 10,
    name: "Day of Ashura",
    arabic: "يوم عاشوراء",
    description: "A day of fasting commemorating Moses being saved from Pharaoh.",
  },
  {
    month: 3,
    day: 12,
    name: "Mawlid al-Nabi",
    arabic: "المولد النبوي",
    description: "Birthday of Prophet Muhammad (PBUH).",
  },
  {
    month: 7,
    day: 27,
    name: "Isra and Miraj",
    arabic: "الإسراء والمعراج",
    description: "Night journey and ascension of Prophet Muhammad (PBUH).",
  },
  {
    month: 8,
    day: 15,
    name: "Shab e Barat",
    arabic: "ليلة البراءة",
    description: "The Night of Fortune and Forgiveness.",
  },
  {
    month: 9,
    day: 1,
    name: "Start of Ramadan",
    arabic: "بداية رمضان",
    description: "Beginning of the holy month of fasting.",
  },
  {
    month: 9,
    day: 27,
    name: "Laylat al-Qadr",
    arabic: "ليلة القدر",
    description: "The Night of Power, holiest night in Islam.",
  },
  {
    month: 10,
    day: 1,
    name: "Eid al-Fitr",
    arabic: "عيد الفطر",
    description: "Festival of Breaking the Fast, celebrating end of Ramadan.",
  },
  {
    month: 12,
    day: 8,
    name: "Day of Arafah",
    arabic: "يوم عرفة",
    description: "Day before Eid al-Adha, pilgrims gather at Mount Arafah.",
  },
  {
    month: 12,
    day: 10,
    name: "Eid al-Adha",
    arabic: "عيد الأضحى",
    description: "Festival of Sacrifice, commemorating Ibrahim's willingness.",
  },
]

const prayers = [
  { id: "fajr", name: "Fajr", arabic: "الفجر", key: "Fajr" },
  { id: "sunrise", name: "Sunrise", arabic: "الشروق", key: "Sunrise" },
  { id: "dhuhr", name: "Dhuhr", arabic: "الظهر", key: "Dhuhr" },
  { id: "asr", name: "Asr", arabic: "العصر", key: "Asr" },
  { id: "maghrib", name: "Maghrib", arabic: "المغرب", key: "Maghrib" },
  { id: "isha", name: "Isha", arabic: "العشاء", key: "Isha" },
]

const duas = [
  {
    title: "Morning Remembrance",
    arabic: "أَصْبَحْنَا وَأَصْبَحَ الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ",
    translation:
      "We have reached the morning and at this very time all sovereignty belongs to Allah. All praise is for Allah.",
    transliteration: "Asbahna wa asbahal mulku lillah, walhamdu lillah",
  },
  {
    title: "Before Sleeping",
    arabic: "بِاسْمِكَ اللَّهُمَّ أَمُوتُ وَأَحْيَا",
    translation: "In Your name, O Allah, I die and I live.",
    transliteration: "Bismika Allahumma amootu wa ahya",
  },
  {
    title: "Entering Home",
    arabic: "اللَّهُمَّ إِنِّي أَسْأَلُكَ خَيْرَ الْمَوْلَجِ وَخَيْرَ الْمَخْرَجِ",
    translation: "O Allah, I ask You for the best entrance and the best exit.",
    transliteration: "Allahumma inni as'aluka khayral mawliji wa khayral makhraji",
  },
  {
    title: "Before Eating",
    arabic: "بِسْمِ اللَّهِ وَعَلَى بَرَكَةِ اللَّهِ",
    translation: "In the name of Allah and with the blessings of Allah.",
    transliteration: "Bismillahi wa 'ala barakatillah",
  },
  {
    title: "After Eating",
    arabic: "الْحَمْدُ لِلَّهِ الَّذِي أَطْعَمَنَا وَسَقَانَا وَجَعَلَنَا مُسْلِمِينَ",
    translation: "All praise is for Allah who fed us, gave us drink, and made us Muslims.",
    transliteration: "Alhamdulillahil-ladhi at'amana wa saqana wa ja'alana muslimeen",
  },
  {
    title: "For Protection",
    arabic: "بِسْمِ اللَّهِ الَّذِي لَا يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي الْأَرْضِ وَلَا فِي السَّمَاءِ",
    translation: "In the name of Allah, with whose name nothing on earth or in heaven can cause harm.",
    transliteration: "Bismillahil-ladhi la yadurru ma'asmihi shay'un fil-ardi wa la fis-sama'",
  },
]

const quranVerses = [
  {
    arabic: "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ",
    translation: "In the name of Allah, the Most Gracious, the Most Merciful.",
    ref: "Al-Fatiha 1:1",
  },
  {
    arabic: "الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ",
    translation: "All praise is due to Allah, Lord of all the worlds.",
    ref: "Al-Fatiha 1:2",
  },
  {
    arabic: "إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ",
    translation: "You alone we worship, and You alone we ask for help.",
    ref: "Al-Fatiha 1:5",
  },
  { arabic: "فَإِنَّ مَعَ الْعُسْرِ يُسْرًا", translation: "For indeed, with hardship comes ease.", ref: "Ash-Sharh 94:5" },
  {
    arabic: "وَمَن يَتَوَكَّلْ عَلَى اللَّهِ فَهُوَ حَسْبُهُ",
    translation: "And whoever relies upon Allah - then He is sufficient for him.",
    ref: "At-Talaq 65:3",
  },
  {
    arabic: "رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً",
    translation: "Our Lord, give us good in this world and good in the Hereafter.",
    ref: "Al-Baqarah 2:201",
  },
  { arabic: "إِنَّ اللَّهَ مَعَ الصَّابِرِينَ", translation: "Indeed, Allah is with the patient.", ref: "Al-Baqarah 2:153" },
  {
    arabic: "وَاذْكُر رَّبَّكَ فِي نَفْسِكَ تَضَرُّعًا وَخِيفَةً",
    translation: "And remember your Lord within yourself in humility and in fear.",
    ref: "Al-A'raf 7:205",
  },
]

const arabicNumerals = ["٠", "١", "٢", "٣", "٤", "٥", "٦", "٧", "٨", "٩"]

const LOCATIONS = {
  // Jammu & Kashmir
  srinagar: { lat: 34.0837, lng: 74.7973, name: "Srinagar, J&K", timezone: "Asia/Kolkata" },
  jammu: { lat: 32.7266, lng: 74.857, name: "Jammu, J&K", timezone: "Asia/Kolkata" },
  anantnag: { lat: 33.7311, lng: 75.1487, name: "Anantnag, J&K", timezone: "Asia/Kolkata" },
  baramulla: { lat: 34.198, lng: 74.3636, name: "Baramulla, J&K", timezone: "Asia/Kolkata" },
  pulwama: { lat: 33.8718, lng: 74.8946, name: "Pulwama, J&K", timezone: "Asia/Kolkata" },
  kupwara: { lat: 34.5261, lng: 74.254, name: "Kupwara, J&K", timezone: "Asia/Kolkata" },
  budgam: { lat: 33.9286, lng: 74.7208, name: "Budgam, J&K", timezone: "Asia/Kolkata" },
  ganderbal: { lat: 34.2268, lng: 74.778, name: "Ganderbal, J&K", timezone: "Asia/Kolkata" },
  bandipora: { lat: 34.4174, lng: 74.6437, name: "Bandipora, J&K", timezone: "Asia/Kolkata" },
  kulgam: { lat: 33.6447, lng: 75.0189, name: "Kulgam, J&K", timezone: "Asia/Kolkata" },
  shopian: { lat: 33.7167, lng: 74.8333, name: "Shopian, J&K", timezone: "Asia/Kolkata" },
  // Major Indian Cities
  delhi: { lat: 28.6139, lng: 77.209, name: "New Delhi", timezone: "Asia/Kolkata" },
  mumbai: { lat: 19.076, lng: 72.8777, name: "Mumbai", timezone: "Asia/Kolkata" },
  hyderabad: { lat: 17.385, lng: 78.4867, name: "Hyderabad", timezone: "Asia/Kolkata" },
  bangalore: { lat: 12.9716, lng: 77.5946, name: "Bangalore", timezone: "Asia/Kolkata" },
  chennai: { lat: 13.0827, lng: 80.2707, name: "Chennai", timezone: "Asia/Kolkata" },
  kolkata: { lat: 22.5726, lng: 88.3639, name: "Kolkata", timezone: "Asia/Kolkata" },
  lucknow: { lat: 26.8467, lng: 80.9462, name: "Lucknow", timezone: "Asia/Kolkata" },
  // Holy Cities
  mecca: { lat: 21.4225, lng: 39.8262, name: "Mecca", timezone: "Asia/Riyadh" },
  medina: { lat: 24.5247, lng: 39.5692, name: "Medina", timezone: "Asia/Riyadh" },
  jerusalem: { lat: 31.7683, lng: 35.2137, name: "Jerusalem", timezone: "Asia/Jerusalem" },
}

// ==================== State ====================
const state = {
  currentTab: "home", // Changed from currentView to currentTab
  currentHijriMonth: 0,
  currentHijriYear: 1446,
  currentGregorianMonth: new Date().getMonth(),
  currentGregorianYear: new Date().getFullYear(),
  calendarType: "hijri", // Renamed from currentView to calendarType for clarity
  userLocation: null,
  locationName: "",
  selectedLocation: "srinagar",
  prayerTimes: null,
  calculationMethod: 1, // Karachi/ISC method - best for South Asia
  timeFormat: "12",
  darkMode: false,
  eventsFilter: "upcoming",
  tasbih: { count: 0, target: 33, dhikr: "subhanallah", totalToday: 0, rounds: 0 },
  deviceOrientation: null,
  qiblaAngle: 0,
  notifications: false, // Add notifications state
  hijriDate: null, // Added hijriDate to state
  gregorianDate: new Date(), // Added gregorianDate to state
  calendarMode: "hijri", // Added calendarMode to state
  location: {
    // Consolidated location data
    lat: 34.0837,
    lng: 74.7973,
  },
  locationName: "Srinagar, J&K", // Simplified locationName
  selectedLocation: "srinagar", // Renamed from userLocation to selectedLocation
}

// ==================== Utilities ====================
function toArabicNumerals(num) {
  return String(num)
    .split("")
    .map((d) => arabicNumerals[Number.parseInt(d)] || d)
    .join("")
}

function showToast(message, type = "info") {
  const toast = document.getElementById("toast")
  const toastMessage = document.getElementById("toast-message")
  toastMessage.textContent = message
  toast.className = `toast ${type}` // Reset classes and add new type
  toast.classList.add("active")
  setTimeout(() => toast.classList.remove("active"), 3000)
}

function formatTime(timeStr, format = "12") {
  if (!timeStr) return "--:--"
  const time = timeStr.split(" ")[0]
  const [hours, minutes] = time.split(":")
  const hour = Number.parseInt(hours)

  if (format === "24") return `${hours}:${minutes}`

  const ampm = hour >= 12 ? "PM" : "AM"
  const hour12 = hour % 12 || 12
  return `${hour12}:${minutes} ${ampm}`
}

function saveState() {
  localStorage.setItem(
    "islamuna_state",
    JSON.stringify({
      calculationMethod: state.calculationMethod,
      timeFormat: state.timeFormat,
      darkMode: state.darkMode,
      notifications: state.notifications, // Save notifications preference
      tasbih: state.tasbih,
      selectedLocation: state.selectedLocation,
    }),
  )
}

function loadState() {
  const saved = localStorage.getItem("islamuna_state")
  if (saved) {
    const parsed = JSON.parse(saved)
    Object.assign(state, parsed)

    // Check if tasbih was from a different day
    const lastDate = localStorage.getItem("islamuna_tasbih_date")
    const today = new Date().toDateString()
    if (lastDate !== today) {
      state.tasbih.totalToday = 0
      state.tasbih.rounds = 0
      localStorage.setItem("islamuna_tasbih_date", today)
    }
  }
  // Load from localStorage directly as well for convenience
  const savedMethod = localStorage.getItem("islamuna_method")
  const savedTimeFormat = localStorage.getItem("islamuna_timeformat")
  const savedDarkMode = localStorage.getItem("islamuna_darkmode")
  const savedLocation = localStorage.getItem("islamuna_location")
  const savedNotifications = localStorage.getItem("islamuna_notifications") // Load notifications

  if (savedMethod) state.calculationMethod = Number.parseInt(savedMethod)
  if (savedTimeFormat) state.timeFormat = savedTimeFormat
  if (savedDarkMode === "true") {
    state.darkMode = true
  }
  if (savedNotifications === "true" && Notification.permission === "granted") {
    // Check permission
    state.notifications = true
  }
  if (savedLocation && (savedLocation === "auto" || LOCATIONS[savedLocation])) {
    state.selectedLocation = savedLocation
  } else {
    // Default to Srinagar if nothing saved or invalid
    state.selectedLocation = "srinagar"
  }
}

// ==================== Date Conversion ====================
function gregorianToHijri(gYear, gMonth, gDay) {
  const a = Math.floor((14 - gMonth) / 12)
  const y = gYear + 4800 - a
  const m = gMonth + 12 * a - 3
  const jd =
    gDay +
    Math.floor((153 * m + 2) / 5) +
    365 * y +
    Math.floor(y / 4) -
    Math.floor(y / 100) +
    Math.floor(y / 400) -
    32045

  const l = jd - 1948440 + 10632
  const n = Math.floor((l - 1) / 10631)
  const l2 = l - 10631 * n + 354
  const j =
    Math.floor((10985 - l2) / 5316) * Math.floor((50 * l2) / 17719) +
    Math.floor(l2 / 5670) * Math.floor((43 * l2) / 15238)
  const l3 =
    l2 -
    Math.floor((30 - j) / 15) * Math.floor((17719 * j) / 50) -
    Math.floor(j / 16) * Math.floor((15238 * j) / 43) +
    29
  const month = Math.floor((24 * l3) / 709)
  const day = l3 - Math.floor((709 * month) / 24)
  const year = 30 * n + j - 30

  return { year, month, day }
}

function hijriToGregorian(hYear, hMonth, hDay) {
  const jd =
    Math.floor((11 * hYear + 3) / 30) + 354 * hYear + 30 * hMonth - Math.floor((hMonth - 1) / 2) + hDay + 1948440 - 385

  const l = jd + 68569
  const n = Math.floor((4 * l) / 146097)
  const l2 = l - Math.floor((146097 * n + 3) / 4)
  const i = Math.floor((4000 * (l2 + 1)) / 1461001)
  const l3 = l2 - Math.floor((1461 * i) / 4) + 31
  const j = Math.floor((80 * l3) / 2447)
  const day = l3 - Math.floor((2447 * j) / 80)
  const l4 = Math.floor(j / 11)
  const month = j + 2 - 12 * l4
  const year = 100 * (n - 49) + i + l4

  return { year, month, day }
}

function getFirstDayOfHijriMonth(hYear, hMonth) {
  return hijriToGregorian(hYear, hMonth, 1)
}

function getDaysInHijriMonth(year, month) {
  const leapYears = [2, 5, 7, 10, 13, 16, 18, 21, 24, 26, 29]
  const isLeapYear = leapYears.includes(year % 30)
  if (month === 12 && isLeapYear) return 30
  return hijriMonths[month - 1].days
}

function getDaysInGregorianMonth(year, month) {
  return new Date(year, month, 0).getDate()
}

// ==================== Clock ====================
function updateClock() {
  const now = new Date()
  const hours = now.getHours()
  const minutes = now.getMinutes()
  const seconds = now.getSeconds()

  let timeStr
  if (state.timeFormat === "24") {
    timeStr = `${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}`
  } else {
    const ampm = hours >= 12 ? "PM" : "AM"
    const hour12 = hours % 12 || 12
    timeStr = `${hour12}:${minutes.toString().padStart(2, "0")} ${ampm}`
  }

  document.getElementById("live-clock").textContent = timeStr
  document.getElementById("live-seconds").textContent = seconds.toString().padStart(2, "0")
}

// ==================== Date Display ====================
function updateDateDisplay() {
  const today = new Date()
  const hijri = gregorianToHijri(today.getFullYear(), today.getMonth() + 1, today.getDate())

  document.getElementById("hijri-full-date").textContent =
    `${hijri.day} ${hijriMonths[hijri.month - 1].name} ${hijri.year}`
  document.getElementById("hijri-arabic").textContent =
    `${toArabicNumerals(hijri.day)} ${hijriMonths[hijri.month - 1].arabic} ${toArabicNumerals(hijri.year)}`

  document.getElementById("gregorian-full-date").textContent = today.toLocaleDateString("en-US", {
    month: "long",
    day: "numeric",
    year: "numeric",
  })
  document.getElementById("gregorian-weekday").textContent = weekDays[today.getDay()]

  state.currentHijriMonth = hijri.month - 1
  state.currentHijriYear = hijri.year
  state.currentGregorianMonth = today.getMonth()
  state.currentGregorianYear = today.getFullYear()
}

// ==================== Prayer Times ====================
function renderPrayerList() {
  const container = document.getElementById("prayer-list")
  container.innerHTML = prayers
    .map(
      (prayer) => `
    <div class="prayer-item" data-prayer="${prayer.id}">
      <div class="prayer-icon-wrapper ${prayer.id}">
        ${getPrayerIcon(prayer.id)}
      </div>
      <div class="prayer-details">
        <span class="prayer-name-en">${prayer.name}</span>
        <span class="prayer-name-ar">${prayer.arabic}</span>
      </div>
      <span class="prayer-time" id="${prayer.id}-time">--:--</span>
      <span class="prayer-status" id="${prayer.id}-status"></span>
    </div>
  `,
    )
    .join("")
}

function getPrayerIcon(id) {
  const icons = {
    fajr: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 3a9 9 0 109 9c0-.46-.04-.92-.1-1.36a5.389 5.389 0 01-4.4 2.26 5.403 5.403 0 01-3.14-9.8c-.44-.06-.9-.1-1.36-.1z"/></svg>',
    sunrise:
      '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 7c-2.76 0-5 2.24-5 5s2.24 5 5 5 5-2.24 5-5-2.24-5-5-5zM2 13h2c.55 0 1-.45 1-1s-.45-1-1-1H2c-.55 0-1 .45-1 1s.45 1 1 1zM11 2v2c0 .55.45 1 1 1s1-.45 1-1V2c0-.55-.45-1-1-1s-1 .45-1 1z"/></svg>',
    dhuhr:
      '<svg viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="12" r="5"/><path d="M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42"/></svg>',
    asr: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 7c-2.76 0-5 2.24-5 5s2.24 5 5 5 5-2.24 5-5-2.24-5-5-5z"/><path d="M12 3v2M12 19v2M5.64 5.64l1.41 1.41M16.95 16.95l1.41 1.41M3 12h2M19 12h2"/></svg>',
    maghrib:
      '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M17 12c0-2.76-2.24-5-5-5s-5 2.24-5 5h10zM1 18h22v2H1zM5 14h14"/></svg>',
    isha: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 3a9 9 0 109 9c0-.46-.04-.92-.1-1.36a5.389 5.389 0 01-4.4 2.26 5.403 5.403 0 01-3.14-9.8c-.44-.06-.9-.1-1.36-.1z"/><circle cx="18" cy="5" r="1"/><circle cx="15" cy="3" r="0.5"/></svg>',
  }
  return icons[id] || ""
}

async function setLocation(locationKey) {
  if (locationKey === "auto") {
    const autoLocation = await getLocation()
    if (autoLocation) {
      state.userLocation = autoLocation
      state.locationName = "Current Location"
      state.selectedLocation = "auto"
    } else {
      // Fallback to Srinagar if auto-detect fails
      showToast("Could not detect location. Using Srinagar.", "warning")
      setLocationFromDatabase("srinagar")
    }
  } else {
    setLocationFromDatabase(locationKey)
  }

  // Save to localStorage
  localStorage.setItem("islamuna_location", state.selectedLocation)

  // Update UI and fetch new prayer times
  document.getElementById("location-text").textContent = state.locationName
  await fetchPrayerTimes()
  calculateQibla()
}

function setLocationFromDatabase(locationKey) {
  const loc = LOCATIONS[locationKey]
  if (loc) {
    state.userLocation = { lat: loc.lat, lng: loc.lng }
    state.locationName = loc.name
    state.selectedLocation = locationKey
  }
}

async function fetchPrayerTimes() {
  if (!state.userLocation) return

  const { lat, lng } = state.userLocation
  const today = new Date()
  const dateStr = `${today.getDate()}-${today.getMonth() + 1}-${today.getFullYear()}`

  try {
    const res = await fetch(
      `https://api.aladhan.com/v1/timings/${dateStr}?latitude=${lat}&longitude=${lng}&method=${state.calculationMethod}&school=1`,
    )
    const data = await res.json()

    if (data.code === 200) {
      state.prayerTimes = data.data.timings
      updatePrayerUI() // Renamed updatePrayerDisplay to updatePrayerUI

      document.getElementById("location-text").textContent = state.locationName || "Your Location"
    }
  } catch (err) {
    console.error("Prayer times error:", err)
    showToast("Could not load prayer times", "error")
  }
}

function updatePrayerUI() {
  // Renamed from updatePrayerDisplay
  if (!state.prayerTimes) return

  prayers.forEach((prayer) => {
    const timeEl = document.getElementById(`${prayer.id}-time`)
    if (timeEl) {
      timeEl.textContent = formatTime(state.prayerTimes[prayer.key], state.timeFormat)
    }
  })

  updatePrayerStatuses()
}

function updatePrayerStatuses() {
  if (!state.prayerTimes) return

  const now = new Date()
  const currentMinutes = now.getHours() * 60 + now.getMinutes()

  const prayerMinutes = prayers.map((p) => {
    const time = state.prayerTimes[p.key]
    if (!time) return { ...p, minutes: 0 }
    const [hours, minutes] = time.split(" ")[0].split(":")
    return { ...p, minutes: Number.parseInt(hours) * 60 + Number.parseInt(minutes) }
  })

  let nextPrayerIndex = prayerMinutes.findIndex((p) => p.minutes > currentMinutes)
  if (nextPrayerIndex === -1) nextPrayerIndex = 0
  const currentPrayerIndex = nextPrayerIndex === 0 ? prayerMinutes.length - 1 : nextPrayerIndex - 1

  // Clear all statuses
  document.querySelectorAll(".prayer-item").forEach((el) => {
    el.classList.remove("current", "next", "passed")
  })
  document.querySelectorAll(".prayer-status").forEach((el) => {
    el.className = "prayer-status"
    el.textContent = ""
  })

  // Set statuses
  prayers.forEach((prayer, index) => {
    const statusEl = document.getElementById(`${prayer.id}-status`)
    const itemEl = document.querySelector(`[data-prayer="${prayer.id}"]`)
    if (!statusEl || !itemEl) return

    if (index === currentPrayerIndex && prayer.id !== "sunrise") {
      itemEl.classList.add("current")
      statusEl.classList.add("current")
      statusEl.textContent = "Current"
    } else if (index === nextPrayerIndex) {
      itemEl.classList.add("next")
      statusEl.classList.add("next")
      statusEl.textContent = "Next"
    } else if (prayerMinutes[index].minutes < currentMinutes && index < nextPrayerIndex) {
      itemEl.classList.add("passed")
      statusEl.classList.add("passed")
      statusEl.textContent = "Passed"
    }
  })

  // Update next prayer banner
  const nextPrayer = prayerMinutes[nextPrayerIndex]
  let minutesUntil = nextPrayer.minutes - currentMinutes
  if (minutesUntil < 0) minutesUntil += 24 * 60

  const hours = Math.floor(minutesUntil / 60)
  const mins = minutesUntil % 60
  const secs = 59 - now.getSeconds()

  document.getElementById("next-prayer-name").textContent = nextPrayer.name
  document.getElementById("next-prayer-adhan").textContent = formatTime(
    state.prayerTimes[nextPrayer.key],
    state.timeFormat,
  )

  const countdownStr = hours > 0 ? `${hours}h ${mins}m` : `${mins}:${secs.toString().padStart(2, "0")}`
  document.getElementById("next-prayer-countdown").textContent = countdownStr

  // Update status text based on current prayer
  const statusText = document.getElementById("prayer-status-text")
  if (minutesUntil <= 15 && minutesUntil > 0) {
    statusText.textContent = "Coming Soon"
    document.getElementById("prayer-banner").style.background = "linear-gradient(135deg, #f59e0b 0%, #d97706 100%)"
  } else {
    statusText.textContent = "Next Prayer"
    document.getElementById("prayer-banner").style.background = ""
  }
}

// ==================== Calendar ====================
function renderHijriCalendar() {
  const container = document.getElementById("hijri-calendar-days")
  const monthData = hijriMonths[state.currentHijriMonth]

  document.getElementById("display-hijri-month-ar").textContent = monthData.arabic
  document.getElementById("display-hijri-month-en").textContent = `${monthData.name} ${state.currentHijriYear}`

  const today = new Date()
  const todayHijri = gregorianToHijri(today.getFullYear(), today.getMonth() + 1, today.getDate())
  const isCurrentMonth = todayHijri.month - 1 === state.currentHijriMonth && todayHijri.year === state.currentHijriYear

  const firstDayGregorian = getFirstDayOfHijriMonth(state.currentHijriYear, state.currentHijriMonth + 1)
  const firstDayDate = new Date(firstDayGregorian.year, firstDayGregorian.month - 1, firstDayGregorian.day)
  const startingDay = firstDayDate.getDay()
  const daysInMonth = getDaysInHijriMonth(state.currentHijriYear, state.currentHijriMonth + 1)

  container.innerHTML = ""

  // Empty cells
  for (let i = 0; i < startingDay; i++) {
    container.innerHTML += '<div class="day-cell empty"></div>'
  }

  // Days
  for (let day = 1; day <= daysInMonth; day++) {
    const gregDate = hijriToGregorian(state.currentHijriYear, state.currentHijriMonth + 1, day)
    const dayOfWeek = (startingDay + day - 1) % 7
    const hasEvent = islamicEvents.some((e) => e.month === state.currentHijriMonth + 1 && e.day === day)

    const classes = ["day-cell"]
    if (isCurrentMonth && day === todayHijri.day) classes.push("today")
    if (dayOfWeek === 5) classes.push("friday")
    if (hasEvent) classes.push("event")

    container.innerHTML += `
      <div class="${classes.join(" ")}" onclick="showDayInfo(${day}, 'hijri')">
        <span class="day-num">${day}</span>
        <span class="day-sub">${gregDate.day}/${gregDate.month}</span>
      </div>
    `
  }
}

function renderGregorianCalendar() {
  const container = document.getElementById("gregorian-calendar-days")

  document.getElementById("display-gregorian-month").textContent =
    `${gregorianMonths[state.currentGregorianMonth]} ${state.currentGregorianYear}`

  const today = new Date()
  const isCurrentMonth =
    today.getMonth() === state.currentGregorianMonth && today.getFullYear() === state.currentGregorianYear

  const firstDay = new Date(state.currentGregorianYear, state.currentGregorianMonth, 1).getDay()
  const daysInMonth = getDaysInGregorianMonth(state.currentGregorianYear, state.currentGregorianMonth + 1)

  container.innerHTML = ""

  // Empty cells
  for (let i = 0; i < firstDay; i++) {
    container.innerHTML += '<div class="day-cell empty"></div>'
  }

  // Days
  for (let day = 1; day <= daysInMonth; day++) {
    const hijriDate = gregorianToHijri(state.currentGregorianYear, state.currentGregorianMonth + 1, day)
    const dayOfWeek = (firstDay + day - 1) % 7
    const hasEvent = islamicEvents.some((e) => e.month === hijriDate.month && e.day === hijriDate.day)

    const classes = ["day-cell"]
    if (isCurrentMonth && day === today.getDate()) classes.push("today")
    if (dayOfWeek === 5) classes.push("friday")
    if (hasEvent) classes.push("event")

    container.innerHTML += `
      <div class="${classes.join(" ")}" onclick="showDayInfo(${day}, 'gregorian')">
        <span class="day-num">${day}</span>
        <span class="day-sub">${hijriDate.day} ${hijriMonths[hijriDate.month - 1].arabic.slice(0, 2)}</span>
      </div>
    `
  }
}

function showDayInfo(day, type) {
  let hijriDate, gregDate

  if (type === "hijri") {
    hijriDate = { year: state.currentHijriYear, month: state.currentHijriMonth + 1, day }
    gregDate = hijriToGregorian(hijriDate.year, hijriDate.month, day)
  } else {
    gregDate = { year: state.currentGregorianYear, month: state.currentGregorianMonth + 1, day }
    hijriDate = gregorianToHijri(gregDate.year, gregDate.month, day)
  }

  const events = islamicEvents.filter((e) => e.month === hijriDate.month && e.day === hijriDate.day)
  const dayOfWeek = new Date(gregDate.year, gregDate.month - 1, gregDate.day).getDay()

  document.getElementById("day-modal-title").textContent = weekDays[dayOfWeek]

  let bodyHTML = `
    <div style="text-align: center; margin-bottom: 1rem;">
      <p style="font-size: 0.9rem; color: var(--text-primary); font-weight: 600;">
        ${hijriDate.day} ${hijriMonths[hijriDate.month - 1].name} ${hijriDate.year}
      </p>
      <p style="font-family: 'Amiri', serif; font-size: 1rem; color: var(--primary);">
        ${toArabicNumerals(hijriDate.day)} ${hijriMonths[hijriDate.month - 1].arabic} ${toArabicNumerals(hijriDate.year)}
      </p>
      <p style="font-size: 0.8rem; color: var(--text-secondary); margin-top: 0.5rem;">
        ${gregDate.day} ${gregorianMonths[gregDate.month - 1]} ${gregDate.year}
      </p>
    </div>
  `

  if (events.length > 0) {
    bodyHTML += '<div style="border-top: 1px solid var(--border); padding-top: 1rem;">'
    bodyHTML += '<h4 style="font-size: 0.85rem; color: var(--text-primary); margin-bottom: 0.5rem;">Islamic Events</h4>'
    events.forEach((e) => {
      bodyHTML += `
        <div style="background: var(--bg-light); padding: 0.75rem; border-radius: 8px; margin-bottom: 0.5rem;">
          <p style="font-weight: 600; color: var(--primary);">${e.name}</p>
          <p style="font-family: 'Amiri', serif; color: var(--text-secondary);">${e.arabic}</p>
          <p style="font-size: 0.75rem; color: var(--text-light); margin-top: 0.25rem;">${e.description}</p>
        </div>
      `
    })
    bodyHTML += "</div>"
  }

  document.getElementById("day-modal-body").innerHTML = bodyHTML
  document.getElementById("day-modal").classList.add("active")
}

// ==================== Qibla ====================
function calculateQibla() {
  if (!state.userLocation) return

  const meccaLat = (21.4225 * Math.PI) / 180
  const meccaLng = (39.8262 * Math.PI) / 180
  const userLat = (state.userLocation.lat * Math.PI) / 180
  const userLng = (state.userLocation.lng * Math.PI) / 180

  const y = Math.sin(meccaLng - userLng)
  const x = Math.cos(userLat) * Math.tan(meccaLat) - Math.sin(userLat) * Math.cos(meccaLng - userLng)

  let qibla = (Math.atan2(y, x) * 180) / Math.PI
  if (qibla < 0) qibla += 360

  state.qiblaAngle = qibla
  document.getElementById("qibla-marker").style.transform = `translateX(-50%) rotate(${qibla}deg)`
  document.getElementById("qibla-degree").textContent = `${Math.round(qibla)}°`

  // Calculate distance to Mecca
  const R = 6371 // Earth's radius in km
  const dLat = meccaLat - userLat
  const dLng = meccaLng - userLng
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(userLat) * Math.cos(meccaLat) * Math.sin(dLng / 2) ** 2
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
  const distance = R * c

  document.getElementById("qibla-distance").textContent = `${Math.round(distance).toLocaleString()} km to Mecca`
}

function setupCompass() {
  if (window.DeviceOrientationEvent) {
    window.addEventListener("deviceorientation", (e) => {
      if (e.alpha !== null) {
        state.deviceOrientation = e.alpha
        const needle = document.getElementById("compass-needle")
        if (needle) {
          needle.style.transform = `rotate(${-e.alpha}deg)`
        }
        document.getElementById("qibla-hint").textContent = "Compass active - point device north"
      }
    })
  }
}

// ==================== Tasbih ====================
function updateTasbihDisplay() {
  document.getElementById("tasbih-count").textContent = state.tasbih.count
  document.getElementById("tasbih-target-text").textContent = `Goal: ${state.tasbih.target}`
  document.getElementById("total-today").textContent = state.tasbih.totalToday
  document.getElementById("total-rounds").textContent = state.tasbih.rounds

  const progress = Math.min((state.tasbih.count / state.tasbih.target) * 100, 100)
  document.getElementById("tasbih-progress").style.width = `${progress}%`
}

function incrementTasbih() {
  state.tasbih.count++
  state.tasbih.totalToday++

  if (state.tasbih.count >= state.tasbih.target) {
    state.tasbih.rounds++
    state.tasbih.count = 0
    showToast("Round completed! MashaAllah")

    // Vibrate if supported
    if (navigator.vibrate) {
      navigator.vibrate([100, 50, 100])
    }
  }

  updateTasbihDisplay()
  saveState()
}

function resetTasbih() {
  state.tasbih.count = 0
  updateTasbihDisplay()
  saveState()
  showToast("Counter reset")
}

// ==================== Duas ====================
function renderDuas() {
  const container = document.getElementById("duas-list")
  container.innerHTML = duas
    .map(
      (dua, index) => `
    <div class="dua-item" onclick="toggleDua(this)">
      <div class="dua-header">
        <span class="dua-title">${dua.title}</span>
        <svg class="dua-expand" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M6 9l6 6 6-6"/>
        </svg>
      </div>
      <p class="dua-arabic">${dua.arabic}</p>
      <p class="dua-translation">${dua.translation}</p>
      <p class="dua-transliteration">${dua.transliteration}</p>
    </div>
  `,
    )
    .join("")
}

function toggleDua(element) {
  element.classList.toggle("expanded")
}

// ==================== Events ====================
function renderEvents() {
  const container = document.getElementById("events-list")
  const today = new Date()
  const todayHijri = gregorianToHijri(today.getFullYear(), today.getMonth() + 1, today.getDate())

  let events = islamicEvents.map((event) => {
    let eventYear = todayHijri.year
    // If event has passed this year, show next year's date
    if (event.month < todayHijri.month || (event.month === todayHijri.month && event.day < todayHijri.day)) {
      eventYear++
    }

    const gregDate = hijriToGregorian(eventYear, event.month, event.day)
    const eventDate = new Date(gregDate.year, gregDate.month - 1, gregDate.day)
    const isPast = eventDate < today
    const daysUntil = Math.ceil((eventDate - today) / (1000 * 60 * 60 * 24))

    return { ...event, gregDate, eventDate, isPast, daysUntil, eventYear }
  })

  events.sort((a, b) => a.eventDate - b.eventDate)

  if (state.eventsFilter === "upcoming") {
    events = events.filter((e) => !e.isPast)
  }

  container.innerHTML =
    events.length === 0
      ? '<p style="text-align: center; color: var(--text-light); padding: 2rem;">No events to display</p>'
      : events
          .map(
            (event) => `
      <div class="event-item ${event.isPast ? "past" : ""}">
        <div class="event-date">
          <span class="day">${event.day}</span>
          <span class="month">${hijriMonths[event.month - 1].arabic}</span>
          <span class="greg">${event.gregDate.day}/${event.gregDate.month}</span>
        </div>
        <div class="event-info">
          <h4 class="event-name">${event.name}</h4>
          <p class="event-name-ar">${event.arabic}</p>
          <p class="event-desc">${event.description}</p>
          ${!event.isPast ? `<span class="event-countdown">${event.daysUntil === 0 ? "Today!" : event.daysUntil === 1 ? "Tomorrow" : `In ${event.daysUntil} days`}</span>` : ""}
        </div>
      </div>
    `,
          )
          .join("")
}

// ==================== Verse of the Day ====================
function updateVerseOfDay() {
  const today = new Date()
  const dayOfYear = Math.floor((today - new Date(today.getFullYear(), 0, 0)) / (1000 * 60 * 60 * 24))
  const verseIndex = dayOfYear % quranVerses.length
  const verse = quranVerses[verseIndex]

  document.getElementById("verse-arabic").textContent = verse.arabic
  document.getElementById("verse-translation").textContent = verse.translation
  document.getElementById("verse-ref").textContent = verse.ref
}

// ==================== Date Converter ====================
function setupConverter() {
  const daySelect = document.getElementById("hijri-day-input")
  for (let i = 1; i <= 30; i++) {
    daySelect.innerHTML += `<option value="${i}">${i}</option>`
  }

  const monthSelect = document.getElementById("hijri-month-input")
  hijriMonths.forEach((month, index) => {
    monthSelect.innerHTML += `<option value="${index + 1}">${month.name}</option>`
  })

  document.getElementById("gregorian-input").valueAsDate = new Date()

  const todayHijri = gregorianToHijri(new Date().getFullYear(), new Date().getMonth() + 1, new Date().getDate())
  document.getElementById("hijri-year-input").value = todayHijri.year

  document.getElementById("convert-to-hijri").addEventListener("click", () => {
    const input = document.getElementById("gregorian-input").value
    if (!input) return
    const [year, month, day] = input.split("-").map(Number)
    const hijri = gregorianToHijri(year, month, day)
    document.getElementById("hijri-result-value").textContent =
      `${hijri.day} ${hijriMonths[hijri.month - 1].name} ${hijri.year} (${hijriMonths[hijri.month - 1].arabic})`
  })

  document.getElementById("convert-to-gregorian").addEventListener("click", () => {
    const day = Number.parseInt(document.getElementById("hijri-day-input").value)
    const month = Number.parseInt(document.getElementById("hijri-month-input").value)
    const year = Number.parseInt(document.getElementById("hijri-year-input").value)
    if (!day || !month || !year) return
    const greg = hijriToGregorian(year, month, day)
    document.getElementById("gregorian-result-value").textContent =
      `${greg.day} ${gregorianMonths[greg.month - 1]} ${greg.year}`
  })
}

// ==================== Location ====================
async function getLocation() {
  return new Promise((resolve) => {
    if (!navigator.geolocation) {
      resolve(null)
      return
    }

    navigator.geolocation.getCurrentPosition(
      (pos) => resolve({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
      () => resolve(null),
      { timeout: 10000, enableHighAccuracy: true },
    )
  })
}

// ==================== Navigation ====================
function setupNavigation() {
  const viewButtons = document.querySelectorAll("[data-view]")
  viewButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
      const view = btn.dataset.view

      document.querySelectorAll(".action-card").forEach((b) => b.classList.remove("active"))
      document.querySelectorAll(".nav-item").forEach((b) => b.classList.remove("active"))
      document.querySelectorAll(`[data-view="${view}"]`).forEach((b) => b.classList.add("active"))

      document.querySelectorAll(".view-section").forEach((s) => s.classList.remove("active"))
      document.getElementById(`${view}-view`).classList.add("active")

      state.currentView = view

      if (view === "calendar") {
        if (state.calendarType === "hijri") renderHijriCalendar()
        else renderGregorianCalendar()
      }
      if (view === "qibla") calculateQibla()
      if (view === "events") renderEvents()
    })
  })

  // Calendar type toggle
  document.querySelectorAll(".type-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".type-btn").forEach((b) => b.classList.remove("active"))
      btn.classList.add("active")

      const type = btn.dataset.type
      state.calendarType = type

      const hijriWrapper = document.getElementById("hijri-calendar-wrapper")
      const gregWrapper = document.getElementById("gregorian-calendar-wrapper")

      if (type === "hijri") {
        hijriWrapper.classList.remove("hidden")
        gregWrapper.classList.add("hidden")
        renderHijriCalendar()
      } else if (type === "gregorian") {
        hijriWrapper.classList.add("hidden")
        gregWrapper.classList.remove("hidden")
        renderGregorianCalendar()
      } else {
        hijriWrapper.classList.remove("hidden")
        gregWrapper.classList.remove("hidden")
        renderHijriCalendar()
        renderGregorianCalendar()
      }
    })
  })

  // Calendar navigation
  document.getElementById("prev-hijri-month").addEventListener("click", () => {
    state.currentHijriMonth--
    if (state.currentHijriMonth < 0) {
      state.currentHijriMonth = 11
      state.currentHijriYear--
    }
    renderHijriCalendar()
  })

  document.getElementById("next-hijri-month").addEventListener("click", () => {
    state.currentHijriMonth++
    if (state.currentHijriMonth > 11) {
      state.currentHijriMonth = 0
      state.currentHijriYear++
    }
    renderHijriCalendar()
  })

  document.getElementById("prev-gregorian-month").addEventListener("click", () => {
    state.currentGregorianMonth--
    if (state.currentGregorianMonth < 0) {
      state.currentGregorianMonth = 11
      state.currentGregorianYear--
    }
    renderGregorianCalendar()
  })

  document.getElementById("next-gregorian-month").addEventListener("click", () => {
    state.currentGregorianMonth++
    if (state.currentGregorianMonth > 11) {
      state.currentGregorianMonth = 0
      state.currentGregorianYear++
    }
    renderGregorianCalendar()
  })

  // Converter tabs
  document.querySelectorAll(".converter-tab").forEach((tab) => {
    tab.addEventListener("click", () => {
      document.querySelectorAll(".converter-tab").forEach((t) => t.classList.remove("active"))
      tab.classList.add("active")

      const type = tab.dataset.converter
      document.getElementById("g2h-converter").classList.toggle("hidden", type !== "g2h")
      document.getElementById("h2g-converter").classList.toggle("hidden", type !== "h2g")
    })
  })

  // Events filter
  document.querySelectorAll(".filter-chip").forEach((chip) => {
    chip.addEventListener("click", () => {
      document.querySelectorAll(".filter-chip").forEach((c) => c.classList.remove("active"))
      chip.classList.add("active")
      state.eventsFilter = chip.dataset.filter
      renderEvents()
    })
  })

  // Tasbih
  document.getElementById("tasbih-button").addEventListener("click", incrementTasbih)
  document.getElementById("reset-tasbih").addEventListener("click", resetTasbih)

  document.querySelectorAll(".dhikr-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".dhikr-btn").forEach((b) => b.classList.remove("active"))
      btn.classList.add("active")
      state.tasbih.dhikr = btn.dataset.dhikr
      state.tasbih.target = Number.parseInt(btn.dataset.target)
      state.tasbih.count = 0
      updateTasbihDisplay()
    })
  })

  // Settings modal open/close
  document.getElementById("settings-btn").addEventListener("click", () => {
    document.getElementById("settings-modal").classList.add("active")
  })

  document.getElementById("close-settings").addEventListener("click", () => {
    document.getElementById("settings-modal").classList.remove("active")
  })

  document.getElementById("close-day-modal").addEventListener("click", () => {
    document.getElementById("day-modal").classList.remove("active")
  })

  // Close modals on overlay click
  document.querySelectorAll(".modal-overlay").forEach((modal) => {
    modal.addEventListener("click", (e) => {
      if (e.target === modal) modal.classList.remove("active")
    })
  })

  // Share verse
  document.getElementById("share-verse").addEventListener("click", () => {
    const verse = document.getElementById("verse-arabic").textContent
    const translation = document.getElementById("verse-translation").textContent
    const ref = document.getElementById("verse-ref").textContent

    const text = `${verse}\n\n"${translation}"\n\n- ${ref}`

    if (navigator.share) {
      navigator.share({ title: "Verse of the Day", text })
    } else {
      navigator.clipboard.writeText(text)
      showToast("Verse copied to clipboard")
    }
  })

  // Qibla calibrate
  document.getElementById("calibrate-compass").addEventListener("click", () => {
    if (window.DeviceOrientationEvent && typeof DeviceOrientationEvent.requestPermission === "function") {
      DeviceOrientationEvent.requestPermission()
        .then((response) => {
          if (response === "granted") {
            setupCompass()
            showToast("Compass calibrated")
          }
        })
        .catch(console.error)
    } else {
      setupCompass()
      showToast("Compass calibrated")
    }
  })
}

function setupSettingsListeners() {
  console.log("[v0] Setting up settings listeners...")

  // Location settings
  const locationSelect = document.getElementById("settings-location")
  if (locationSelect) {
    console.log("[v0] Found location select, current value:", locationSelect.value)
    locationSelect.value = state.selectedLocation
    locationSelect.addEventListener("change", async (e) => {
      console.log("[v0] Location changed to:", e.target.value)
      await setLocation(e.target.value)
      showToast(`Location set to ${state.locationName}`, "success")
    })
  } else {
    console.log("[v0] Location select not found!")
  }

  // Calculation Method
  const methodSelect = document.getElementById("settings-method")
  if (methodSelect) {
    console.log("[v0] Found method select, current value:", methodSelect.value)
    methodSelect.value = state.calculationMethod
    methodSelect.addEventListener("change", async (e) => {
      console.log("[v0] Method changed to:", e.target.value)
      state.calculationMethod = Number.parseInt(e.target.value)
      localStorage.setItem("islamuna_method", e.target.value)
      const otherMethodSelect = document.getElementById("calculation-method")
      if (otherMethodSelect) otherMethodSelect.value = e.target.value
      saveState()
      await fetchPrayerTimes()
      showToast("Calculation method updated", "success")
    })
  } else {
    console.log("[v0] Method select not found!")
  }

  // Time Format
  const timeFormatSelect = document.getElementById("settings-time-format")
  if (timeFormatSelect) {
    console.log("[v0] Found time format select, current value:", timeFormatSelect.value)
    timeFormatSelect.value = state.timeFormat
    timeFormatSelect.addEventListener("change", (e) => {
      console.log("[v0] Time format changed to:", e.target.value)
      state.timeFormat = e.target.value
      localStorage.setItem("islamuna_timeformat", e.target.value)
      saveState()
      renderPrayerList() // Changed from updatePrayerUI to renderPrayerList as per update context
      showToast(`Time format set to ${e.target.value} hour`, "success")
    })
  } else {
    console.log("[v0] Time format select not found!")
  }

  // Notifications
  const notificationsCheckbox = document.getElementById("settings-notifications")
  if (notificationsCheckbox) {
    console.log("[v0] Found notifications checkbox, current checked:", notificationsCheckbox.checked)
    notificationsCheckbox.checked = state.notifications
    notificationsCheckbox.addEventListener("change", async (e) => {
      console.log("[v0] Notifications changed to:", e.target.checked)
      if (e.target.checked) {
        if ("Notification" in window) {
          const permission = await Notification.requestPermission()
          if (permission === "granted") {
            state.notifications = true
            localStorage.setItem("islamuna_notifications", "true")
            showToast("Notifications enabled", "success")
          } else {
            e.target.checked = false
            state.notifications = false
            localStorage.setItem("islamuna_notifications", "false")
            showToast("Notification permission denied", "error")
          }
        } else {
          e.target.checked = false
          state.notifications = false
          localStorage.setItem("islamuna_notifications", "false")
          showToast("Notifications not supported", "error")
        }
      } else {
        state.notifications = false
        localStorage.setItem("islamuna_notifications", "false")
        showToast("Notifications disabled", "info")
      }
      saveState()
    })
  } else {
    console.log("[v0] Notifications checkbox not found!")
  }

  // Dark Mode
  const darkModeCheckbox = document.getElementById("settings-darkmode")
  if (darkModeCheckbox) {
    console.log("[v0] Found dark mode checkbox, current checked:", darkModeCheckbox.checked)
    darkModeCheckbox.checked = state.darkMode
    darkModeCheckbox.addEventListener("change", (e) => {
      console.log("[v0] Dark mode changed to:", e.target.checked)
      state.darkMode = e.target.checked
      localStorage.setItem("islamuna_darkmode", e.target.checked.toString())
      if (e.target.checked) {
        document.documentElement.setAttribute("data-theme", "dark")
      } else {
        document.documentElement.removeAttribute("data-theme")
      }
      saveState()
      showToast(`Dark mode ${e.target.checked ? "enabled" : "disabled"}`, "success")
    })
  } else {
    console.log("[v0] Dark mode checkbox not found!")
  }

  console.log("[v0] Settings listeners setup complete")
}

// ==================== Initialize ====================
async function init() {
  console.log("[v0] Initializing app...")
  loadState()
  console.log("[v0] State loaded:", JSON.stringify(state, null, 2))

  // Apply dark mode immediately if saved
  if (state.darkMode) {
    document.documentElement.setAttribute("data-theme", "dark")
  }

  setupSettingsListeners()
  console.log("[v0] Settings listeners attached")

  // Set location
  if (state.selectedLocation === "auto") {
    await setLocation("auto")
  } else if (LOCATIONS[state.selectedLocation]) {
    await setLocation(state.selectedLocation)
  } else {
    // Default to Srinagar if saved location is invalid
    await setLocation("srinagar")
  }

  // Initialize Hijri date
  const hijriToday = gregorianToHijri(new Date().getFullYear(), new Date().getMonth() + 1, new Date().getDate())
  state.currentHijriMonth = hijriToday.month - 1
  state.currentHijriYear = hijriToday.year

  // Setup navigation (without duplicate settings setup)
  setupNavigation()
  setupConverter()

  // Update and render initial views
  updateClock()
  setInterval(updateClock, 1000)
  updateDateDisplay()
  renderPrayerList()
  renderHijriCalendar()
  renderGregorianCalendar()
  renderEvents()
  renderDuas()
  updateVerseOfDay()
  updateTasbihDisplay()

  // Fetch initial prayer times and Qibla
  await fetchPrayerTimes()
  calculateQibla()
  setupCompass()

  // Update prayer statuses every second
  setInterval(() => {
    updatePrayerStatuses()
  }, 1000)

  // Hide splash screen
  setTimeout(() => {
    document.getElementById("splash").classList.add("hidden")
    document.getElementById("app").classList.add("visible")
    console.log("[v0] App initialized successfully")
  }, 2000)
}

// Start app
document.addEventListener("DOMContentLoaded", init)

// Make functions globally available
window.showDayInfo = showDayInfo
window.toggleDua = toggleDua
